<?php

function omega_check_and_create_table() {
	global $wpdb;

	$table_name = $wpdb->prefix . '_omega_chat';
	
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		orgId tinytext NOT NULL,
		PRIMARY KEY  (id)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );

	// add_option( 'jal_db_version', $jal_db_version );
  omega_crud_operation();
}

function omega_crud_operation() {
	global $wpdb;
	
	$table_name = $wpdb->prefix . '_omega_chat';

  //CHECK ALREADY EXISTS
  $result = $wpdb->get_results("SELECT * FROM $table_name" );
  $current_time = current_time( 'mysql' );
  if ($wpdb->num_rows > 0){
    $rowId=1;
    // UPDATE ORG ID
    $wpdb->query( $wpdb->prepare("UPDATE $table_name SET orgId = '".$_POST['orgId']."', time = '".$current_time."'  WHERE id ='".$rowId."' "));
  }else{
    //  CREATE ORG ID
    $wpdb->insert( $table_name, 
      array( 
        'time' => $current_time, 
        'orgId' => $_POST['orgId']
      ) 
    );
  }
}

if(isset($_POST['submit'])){
  if($_POST['orgId']!=""){
    omega_check_and_create_table();
  }else{
    echo "<p style='color:red'>Please enter valid org ID </p>";
  } 
}
?>

<form action="<?php the_permalink(); ?>" method="post">
     <input type="text" name="orgId">
     <input type="submit" name="submit">
 </form>